﻿using System;

namespace FormAppQuyt.Utils
{
    public static class RandomProvider
    {
        public static readonly Random Shared = new Random();
    }
}
